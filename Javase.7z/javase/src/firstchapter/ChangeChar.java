package Firstchapter;

//演示转义字符的使用
public class ChangeChar {
    //编写一个 main 方法
    public static void main(String[] args) {
//\t ：一个制表位，实现对齐的功能
        System.out.println("北京\t 天津\t 上海");
// \n ：换行符
        System.out.println("jack\nsmith\nmary");
// \\ ：一个\
        System.out.println("C:\\Windows\\System32\\cmd.exe");
//  \":一个:
        System.out.println("你\"我");
//   \':一个'
        System.out.println("java\'c++");
//  \r 表示回车
        System.out.println("湖南\r 北京"); // 北京平教育
    }
}
