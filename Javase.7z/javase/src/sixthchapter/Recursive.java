package Sixthchapter;

public class Recursive {
    public static void main(String[] args) {
        R t = new R();
        t.test(4);
    }
}

class R {
    public void test(int n ){
        if(n > 2){
            test(n - 1);
        }
        System.out.println("n=" + n);
    }
}
