package twentychapter.regexp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regexp_ {
    public static void main(String[] args) {
        String context = "博士论文的题目是：\"The Algebraic Manipulation of Constraints\"。" +
                "毕业后到IBM工作，设计IBM第一代工作站NeWS系统，但不受重视。后来转至Sun公司。" +
                "1990年，与Patrick Naughton和Mike Sheridan等人合作“绿色计划”，后来发展一套语言叫做“Oak”，后改名为Java。" +
                "1994年底，James Gosling在硅谷召开的“技术、教育和设计大会”上展示Java程式。2000年，Java成为世界上最流行的电脑语言。";

        //提取文章的英语
        Pattern compile = Pattern.compile("[a-zA-z]+");
        //提起文章的数字
        Pattern compile1 = Pattern.compile("[0-9]+");
        //提前文章的英文和数字
        Pattern compile2 = Pattern.compile("[a-zA-z0-9]+");
        Matcher matcher = compile.matcher(context);
        Matcher matcher1 = compile1.matcher(context);
        Matcher matcher2 = compile2.matcher(context);
        System.out.println("英文");
        while (matcher.find()) {
            System.out.println(matcher.group(0));
        }
        System.out.println("数字");
        while (matcher1.find()) {
            System.out.println(matcher1.group(0));
        }
        System.out.println("英文和数字");
        while (matcher2.find()) {
            System.out.println(matcher2.group(0));
        }
    }
}
