package eighthchapter;

import eighthchapter.view.HouseView;

public class HouseRentApp {
    public static void main(String[] args) {
        //创建HouseView对象,并且显示主菜单,是整个程序的人口
        new HouseView().mainMenu();
    }
}
