package twelvechapter;

public class Homework2 {
    public static void main(String[] args) {
        String name = "jcak";
        String pwd = "123445";
        String email = "jack@lisi.com";

        try {
            userRegister(name, pwd, email);
            System.out.println("注册成功");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void userRegister(String name, String pwd, String email) {
        int username = name.length();
        if (!(username >= 2 && username <= 4)) {
            throw new RuntimeException("用户名长度为2或3或4");
        }

        int userpwd = pwd.length();
        if (!(userpwd == 6 && isDigtal(pwd))) {
            throw new RuntimeException("密码长度为6,要求全是数字");
        }

        int i = email.indexOf("@");
        int j = email.indexOf(".");
        if (!(i > 0 && j > i)) {
            throw new RuntimeException("邮箱中包含@和. 并且@在.前面");
        }
    }

    public static boolean isDigtal(String str) {
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] <= '0' || chars[i] >= '9') {
                return false;
            }
        }
        return true;
    }
}
