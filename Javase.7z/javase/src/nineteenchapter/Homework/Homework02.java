package nineteenchapter.Homework;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Homework02 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class<?> aClass = Class.forName("java.io.File");
        Constructor<?>[] declaredConstructors = aClass.getDeclaredConstructors();
        for (Constructor<?> declaredConstructor : declaredConstructors) {
            System.out.println(declaredConstructor);
        }
        Constructor<?> declaredConstructor = aClass.getDeclaredConstructor(String.class);
        String fileAllPath = "e:\\mynew.txt";
        Object o = declaredConstructor.newInstance(fileAllPath);
        Method createNewFile = aClass.getMethod("createNewFile");
        createNewFile.invoke(o);
        System.out.println("创建成功");
    }
}
