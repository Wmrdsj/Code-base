package nineteenchapter.classload_;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class ClassLoad_ {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入:");
        String key = scanner.next();
        switch (key) {
            case "1":
                Dog1 dog = new Dog1();//静态加载,依赖性很强
                dog.cry();
                break;
            case "2":
                //反射——动态加载
                Class cls = Class.forName("nineteenchapter.classload_.Person");
                Object o = cls.newInstance();
                Method m = cls.getMethod("hi");
                m.invoke(o);
                System.out.println("ok");
                break;
            default:
                System.out.println("do nothing..");
        }
    }
}

//因为new Dog()是静态加载,因此必须编写Dog
//Person是动态加载,所以没有编写Person类也不会报错,只有在动态加载类的时候才会报错
class Dog1 {
    public void cry() {
        System.out.println("汪汪叫");
    }
}

class Person {
    public void hi() {
        System.out.println("打招呼");
    }
}