package nineteenchapter.class_;

public class Dog {
}
