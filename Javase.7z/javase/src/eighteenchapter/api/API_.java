package eighteenchapter.api;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class API_ {
    public static void main(String[] args) throws UnknownHostException {
        //获取本机 InetAddress 对象 getLocalHost
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println(localHost);

        //根据指定主机名/域名获取 ip 地址对象 getByName
        InetAddress host1 = InetAddress.getByName("wmr");
        System.out.println(host1);

        //根据域名返回InetAddress对象
        InetAddress host2 = InetAddress.getByName("www.baidu.com");
        System.out.println(host2);

        //通过InetAddress对象,获取到对应地址
        String host3Address = host2.getHostAddress();
        System.out.println(host3Address);

        //获取 InetAddress 对象获取主机名 getHostName
        String host3Name = host2.getHostName();
        System.out.println(host3Name);
    }
}
