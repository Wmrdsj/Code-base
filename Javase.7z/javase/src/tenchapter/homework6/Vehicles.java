package Tenchapter.homework6;

public interface Vehicles {
    public void work();
}
