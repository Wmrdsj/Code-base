package Tenchapter.homework6;

public class VehiclesFactory {

    private VehiclesFactory() {
    }

    private static Horse horse = new Horse();

    public static Horse getHorse(){
        return horse;
    }

    public static Boat getBoat(){
        return new Boat();
    }

    public static Plane getPlane(){
        return new Plane();
    }
}
