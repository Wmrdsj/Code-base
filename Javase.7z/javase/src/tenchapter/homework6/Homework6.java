package Tenchapter.homework6;

public class Homework6 {
    public static void main(String[] args) {
        Person tang = new Person("唐僧", new Horse());
        tang.passRiver();
        tang.common();
        tang.passRiver();
        tang.passFireHill();
        tang.common();
        tang.passRiver();
        tang.passFireHill();
        tang.common();
        tang.passRiver();
    }
}


