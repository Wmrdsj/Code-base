package Tenchapter.homework6;

public class Boat implements Vehicles{
    @Override
    public void work() {
        System.out.println("使用船");
    }
}
