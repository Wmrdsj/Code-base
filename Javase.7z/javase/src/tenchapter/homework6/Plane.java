package Tenchapter.homework6;

public class Plane implements Vehicles{
    @Override
    public void work() {
        System.out.println("过火焰山");
    }
}
