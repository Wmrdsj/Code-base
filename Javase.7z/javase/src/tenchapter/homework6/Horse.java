package Tenchapter.homework6;

public class Horse implements Vehicles{
    @Override
    public void work() {
        System.out.println("使用马");
    }
}
