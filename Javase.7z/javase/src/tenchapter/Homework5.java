package Tenchapter;

public class Homework5 {
    public static void main(String[] args) {
        new A().f1();
    }
}

class A{

    private String NAME = "lisi";

    public void f1(){
        class B {

            private final String NAME = "zhangsan";

            public void show() {
                System.out.println("内=" + NAME + "外=" + A.this.NAME);
            }
        }

        B b = new B();
        b.show();
    }
}
