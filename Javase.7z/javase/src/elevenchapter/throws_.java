package elevenchapter;

public class throws_ {
    public static void main(String[] args) {

    }
}
