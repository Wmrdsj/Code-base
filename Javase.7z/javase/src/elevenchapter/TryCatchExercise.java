package elevenchapter;

import java.text.NumberFormat;

public class TryCatchExercise {
    public static int method() {
        int i = 1;
        try {
            i++;
            String[] names = new String[3];
            if (names[1].equals("tom")) {
                System.out.println(names[1]);
            } else {
                names[3] = "占山";
            }
            return 1;
        } catch (ArrayIndexOutOfBoundsException e) {
            return 2;
        } catch (NullPointerException e) {
            return ++i;
        } finally {
            ++i;
            //System.out.println("i=" + i);
        }
    }

    public static void main(String[] args) {
        System.out.println(method());
    }
}
