package Fourthchapter;

public class WhileExercise {
    //编写一个 main 方法
    public static void main(String[] args) {
// 打印 1—100 之间所有能被 3 整除的数
        int i = 1;
        int endNum = 100;
        while( i <= endNum) {
            if( i % 3 == 0) {
                System.out.println("i=" + i);
            }
            i++;//变量自增
        }
// 打印 40—200 之间所有的偶数
        System.out.println("========");
        int j = 40; //变量初始化
        while ( j <= 200) {
//判断
            if( j % 2 == 0) {
                System.out.println("j=" + j);
            }
            j++;//循环变量的迭代
        }
    }
}
