package Fourthchapter;

public class ForExercise02 {
    //编写一个 main 方法
    public static void main(String[] args) {
        int n = 9;
        for( int i = 0; i <= n; i++) {
            System.out.println(i + "+" + (n-i) + "=" + n);
        }
    }
}
