package Secondchapter;

public class IntDetail {
    //编写一个 main 方法
    public static void main(String[] args) {
//Java 的整型常量（具体值）默认为 int 型，声明 long 型常量须后加‘l’或‘L’
        int n1 = 1;//4 个字节
//int n2 = 1L;//对不对?不对
        long n3 = 1L;//对
    }
}
