package Secondchapter;

public class Boolean01 {
    //编写一个 main 方法
    public static void main(String[] args) {
//演示判断成绩是否通过的案例
//定义一个布尔变量
        boolean isPass = true;//
        if(isPass == true) {
            System.out.println("考试通过，恭喜");
        } else {
            System.out.println("考试没有通过，下次努力");
        }
    }
}

