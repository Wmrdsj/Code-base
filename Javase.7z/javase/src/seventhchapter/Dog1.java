package Seventhchapter;

public class Dog1 extends Animal1 {//Dog 是 Animal 的子类
}
