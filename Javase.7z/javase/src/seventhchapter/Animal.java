package Seventhchapter;

public class Animal {
    public void cry() {
        System.out.println("Animal cry() 动物在叫....");
    }
}
