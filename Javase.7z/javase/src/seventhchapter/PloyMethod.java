package Seventhchapter;

public class PloyMethod {
    public static void main(String[] args) {
//方法重载体现多态
        M m = new M();
//这里我们传入不同的参数，就会调用不同 sum 方法，就体现多态
        System.out.println(m.sum(10, 20));
        System.out.println(m.sum(10, 20, 30));
//方法重写体现多态
        U u = new U();
        u.say();
        m.say();
    }
}
class U { //父类
    public void say() {
        System.out.println("B say() 方法被调用...");
    }
}
class M extends U {//子类
    public int sum(int n1, int n2){//和下面 sum 构成重载
        return n1 + n2;
    }
    public int sum(int n1, int n2, int n3){
        return n1 + n2 + n3;
    }
    public void say() {
        System.out.println("A say() 方法被调用...");
    }
}
