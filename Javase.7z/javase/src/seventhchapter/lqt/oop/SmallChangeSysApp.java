package Seventhchapter.lqt.oop;

/**
 * 这里我们直接调用SmallChangeSysOOP对象，显示菜单即可
 * */
public class SmallChangeSysApp {
    public static void main(String[] args) {
        new SmallChangeSysOOP().mainMenu();
    }
}
