package Seventhchapter;

public class PolyDetail {
    public static void main(String[] args) {
//向上转型: 父类的引用指向了子类的对象
//语法：父类类型引用名 = new 子类类型();
        Animal1 animal = new Cat1();
        Object obj = new Cat1();//可以吗? 可以 Object 也是 Cat 的父类
//向上转型调用方法的规则如下:
//(1)可以调用父类中的所有成员(需遵守访问权限)
//(2)但是不能调用子类的特有的成员
//(#)因为在编译阶段，能调用哪些成员,是由编译类型来决定的
//animal.catchMouse();错误
//(4)最终运行效果看子类(运行类型)的具体实现, 即调用方法时，按照从子类(运行类型)开始查找方法
//，然后调用，规则我前面我们讲的方法调用规则一致。
        animal.eat();//猫吃鱼.. animal.run();//跑
        animal.show();//hello,你好
        animal.sleep();//睡
//老师希望，可以调用 Cat 的 catchMouse 方法
//多态的向下转型
//(1)语法：子类类型 引用名 =（子类类型）父类引用;
//问一个问题? cat 的编译类型 Cat,运行类型是 Cat
        Cat1 cat = (Cat1) animal;
        cat.catchMouse();//猫抓老鼠
//(2)要求父类的引用必须指向的是当前目标类型的对象
        Dog1 dog = (Dog1) animal; //可以吗？
        System.out.println("ok~~");
    }
}
