package Seventhchapter;

public class HashCode_ {
    public static void main(String[] args) {
        AAa aa = new AAa();
        AAa aa2 = new AAa();
        AAa aa3 = aa;
        System.out.println("aa.hashCode()=" + aa.hashCode());
        System.out.println("aa2.hashCode()=" + aa2.hashCode());
        System.out.println("aa3.hashCode()=" + aa3.hashCode());
    }
}
class AAa {}
