package Thirdchapter;

//演示四种进制
public class BinaryTest {
    //编写一个 main 方法
    public static void main(String[] args) {
//n1 二进制
        int n1 = 0b1010;
//n2 10 进制
        int n2 = 1010;
//n3 8 进制
        int n3 = 01010;
//n4 16 进制
        int n4 = 0X10101;
        System.out.println("n1=" + n1);
        System.out.println("n2=" + n2);
        System.out.println("n3=" + n3);
        System.out.println("n4=" + n4);
        System.out.println(0x23A);
    }
}
