package Thirteenchapter.HashSet;

public class HashSetStructure {
    public static void main(String[] args) {
        //模拟一个HashSet的底层(HashMap 的底层结构)

        //创建一个数值，类型是Node[]
        //有人叫Node[]为表
        Node[] tables = new Node[16];
        System.out.println(tables);
        //创建结点
        Node john = new Node("john", null);
        tables[2] = john;
        Node jack = new Node("jack", null);
        jack.next = jack;//将jack结点挂载到john
        Node rose = new Node("rose",    null);
        jack.next = rose;
        Node luck = new Node("luck",    null);
        tables[3] = luck;//把luck放到tables索引为3的位置
        System.out.println(tables);
    }
}

class Node { //结点,存储数据,可以指向下一个结点,从而形成链表
    Object item;//存放数据
    Node next;//指向下一个结点

    public Node(Object item, Node next) {
        this.item = item;
        this.next = next;
    }
}
