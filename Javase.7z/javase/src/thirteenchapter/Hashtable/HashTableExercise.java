package Thirteenchapter.Hashtable;

import java.util.Hashtable;

public class HashTableExercise {
    public static void main(String[] args) {
        Hashtable hashtable = new Hashtable();
        hashtable.put("john", 100);//ok
        //hashtable.put(null,100);//异常  NullPointerException
        //hashtable.put("john",null);//异常  NullPointerException
        hashtable.put("lucy", 100);//ok
        hashtable.put("lic", 100);//ok
        hashtable.put("lic", 88);//替换
        hashtable.put("hello1", 1);
        hashtable.put("hello2", 1);
        hashtable.put("hello3", 1);
        hashtable.put("hello4", 1);
        hashtable.put("hello5", 1);
        hashtable.put("hello6", 1);
        hashtable.put("hello7", 1);
        System.out.println(hashtable);
    }

    /*
    1.底层是数组 Hashtable$Entry[] 初始化大小为11
    2.临界值 threshold = 8 = 11 * loadFactor(0.75)
    3.执行方法 addEntry(hash, key, value, index); 添加到k-v 封装到Entry
    4.当(count >= threshold)满足时,就按照int newCapacity = (oldCapacity << 1) + 1;扩容
     */
}
