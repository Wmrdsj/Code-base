package Thirteenchapter.ArrayList;

import java.util.ArrayList;

public class ArrayListDetail {
    public static void main(String[] args) {

        ArrayList arrayList = new ArrayList();
        arrayList.add(null);
        arrayList.add("jack");
        arrayList.add(null);
        System.out.println(arrayList);

        //ArrayList是线程不安全的,源码的方法里面没有 synchronized
        /*public boolean add(E e) {
            ensureCapacityInternal(size + 1);  // Increments modCount!!
            elementData[size++] = e;
            return true;
        }*/
    }
}
