package Fifthchapter;

public class BubbleSort {
    //编写一个 main 方法
    public static void main(String[] args) {
/*
数组 [24,69,80,57,13]
第 1 轮排序: 目标把最大数放在最后
第 1 次比较[24,69,80,57,13]
第 2 次比较[24,69,80,57,13]
第 3 次比较[24,69,57,80,13]
第 4 次比较[24,69,57,13,80]
*/
        int[] arr = {24,69,80,57,13};
        int temp = 0; //用于辅助交换的变量
//将多轮排序使用外层循环包括起来即可
        for( int i = 0; i < arr.length - 1; i++) {//外层循环是 4 次
            for( int j = 0; j < arr.length - 1 - i; j++) {//4 次比较-3 次-2 次-1 次
//如果前面的数>后面的数，就交换
                if(arr[j] > arr[j + 1]) {
                    temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
            System.out.println("\n==第"+(i+1)+"轮==");
            for(int j = 0; j < arr.length; j++) {
                System.out.print(arr[j] + "\t");
            }
        }
// for( int j = 0; j < 4; j++) {//4 次比较
// //如果前面的数>后面的数，就交换
// if(arr[j] > arr[j + 1]) {
// temp = arr[j];
// arr[j] = arr[j+1];
// arr[j+1] = temp;
// }
// }
// System.out.println("==第 1 轮==");
// for(int j = 0; j < arr.length; j++) {
// System.out.print(arr[j] + "\t");
// }
// /*
// 第 2 轮排序: 目标把第二大数放在倒数第二位置
// 第 1 次比较[24,69,57,13,80]
// 第 2 次比较[24,57,69,13,80]
// 第 3 次比较[24,57,13,69,80]
// */
// for( int j = 0; j < 3; j++) {//3 次比较
// //如果前面的数>后面的数，就交换
// if(arr[j] > arr[j + 1]) {
// temp = arr[j];
// arr[j] = arr[j+1];
// arr[j+1] = temp;
// }
// }
// System.out.println("\n==第 2 轮==");
// for(int j = 0; j < arr.length; j++) {
// System.out.print(arr[j] + "\t");
// }
// 第 3 轮排序: 目标把第 3 大数放在倒数第 3 位置
// 第 1 次比较[24,57,13,69,80]
// 第 2 次比较[24,13,57,69,80]
// for( int j = 0; j < 2; j++) {//2 次比较
// //如果前面的数>后面的数，就交换
// if(arr[j] > arr[j + 1]) {
// temp = arr[j];
// arr[j] = arr[j+1];
// arr[j+1] = temp;
// }
// }
// System.out.println("\n==第 3 轮==");
// for(int j = 0; j < arr.length; j++) {
// System.out.print(arr[j] + "\t");
// }
// /*
// 第 4 轮排序: 目标把第 4 大数放在倒数第 4 位置
// 第 1 次比较[13,24,57,69,80]
// */
// for( int j = 0; j < 1; j++) {//1 次比较
// //如果前面的数>后面的数，就交换
// if(arr[j] > arr[j + 1]) {
// temp = arr[j];
// arr[j] = arr[j+1];
// arr[j+1] = temp;
// }
// }
// System.out.println("\n==第 4 轮==");
// for(int j = 0; j < arr.length; j++) {
// System.out.print(arr[j] + "\t");
// }
    }
}
