package ninthchapter;

/**
 * 演示懶漢式的單例模式
 */
public class SingleTon02 {
    public static void main(String[] args) {
//new Cat("大黃");
//System.out.println(Cat.n1);
        Cat1 instance = Cat1.getInstance();
        System.out.println(instance);
//再次調用 getInstance
        Cat1 instance2 = Cat1.getInstance();
        System.out.println(instance2);
        System.out.println(instance == instance2);//T
    }
}
//希望在程序運行過程中，只能創建一個 Cat 對象
//使用單例模式
class Cat1 {
    private String name;
    public static int n1 = 999;
    private static Cat1 cat1 ; //默認是 null
    //步驟
//1.仍然構造器私有化
//2.定義一個 static 靜態屬性對象
//3.提供一個 public 的 static 方法，可以返回一個 Cat 對象
//4.懶漢式，只有當用戶使用 getInstance 時，才返回 cat 對象, 後面再次調用時，會返回上次創建的 cat 對象
// 從而保證了單例

    private Cat1(String name) {
        this.name = name;
    }

    public static Cat1 getInstance(){
        if(cat1 == null){
            cat1 = new Cat1("小可爱");
        }
        return cat1;
    }

    @Override
    public String toString() {
        return "Cat1{" +
                "name='" + name + '\'' +
                '}';
    }
}

