package ninthchapter.interface_;
/*
* 接口类
* */
public interface UsbInterface { //接口
    public void start();

    //规定接口的相关方法,规定的.即规范... public void start();
    public void stop();
}
